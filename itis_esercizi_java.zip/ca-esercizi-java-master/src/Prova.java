
public class Prova {

	public static void main(String[] args) {
		System.out.println(42);
		System.out.println("Prova di modifica");
	}

}
