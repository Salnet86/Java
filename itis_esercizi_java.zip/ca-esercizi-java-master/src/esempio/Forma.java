package esempio;

// superclasse generica Forma
public class Forma {
	public double area() {
		return 0;
	}
	
	public double perimetro() {
		return 0;
	}
}
