package esempio;

public class Pacchetto {

	public static void main(String[] args) {

		System.out.println("Pacchetto");
	}

}
