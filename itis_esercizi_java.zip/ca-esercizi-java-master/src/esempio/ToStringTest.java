package esempio;

public class ToStringTest {

	public static void main(String[] args) {
		Oggetto o = new Oggetto();
		System.out.println(o.toString());
	}

}
