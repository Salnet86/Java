package esempio;

public class Derivata2 extends Base {

	public int m() {
		return 100;
	}

}
