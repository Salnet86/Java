package esempio;

public class Derivata extends Base {

	public int m() {
		return 0;
	}

}
