package esempio;

// classe astratta
public abstract class Base {
	
	// il metodo m � astratto
	public abstract int m();
	
	public int x() {
		return 42;
	}
}
