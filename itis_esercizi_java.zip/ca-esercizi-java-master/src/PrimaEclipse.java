
public class PrimaEclipse {

	public static void main(String[] args) {
		System.out.println("Primo programma con eclipse");
	}

}

