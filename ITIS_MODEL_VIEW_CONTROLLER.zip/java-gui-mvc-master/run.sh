# This will run the 3 MVC Classes
javac src/Model.java src/View.java src/Controller.java src/Driver.java

cd src

java Driver

cd ..