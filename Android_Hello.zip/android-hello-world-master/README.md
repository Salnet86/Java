# Simple Android "Hello World"

Simple **Android Java** "Hello World" Application for educational purposes only.

Using **Android Studio** + **Java** (no need of it).
