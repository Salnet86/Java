package com.rohit.datajpa.util;

public enum PassStatus {
	PASS, FAIL;
}
