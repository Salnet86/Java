package com.rohit.datajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SourceCodeSbhbCollection01ListApplicationTests {

	@Test
	void contextLoads() {
	}

}
