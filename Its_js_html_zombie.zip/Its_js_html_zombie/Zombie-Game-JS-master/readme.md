Simple "game" created with HTML, CSS and JS. Animation was created using following sprite:

![Zombie](http://www.wdrfree.com/public/demos/animatespritekeyframes/walkingdead.png)

Use your mouse and "shoot" the zombie - you have to hit one twice to delete it from the screen.

 # Live Preview

You can view the game by following this link: https://8bit-peter.github.io/Zombie-Game-JS/
