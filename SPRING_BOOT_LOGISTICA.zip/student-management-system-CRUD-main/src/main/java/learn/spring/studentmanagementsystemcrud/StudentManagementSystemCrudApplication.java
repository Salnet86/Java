package learn.spring.studentmanagementsystemcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManagementSystemCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentManagementSystemCrudApplication.class, args);
	}

}
