package learn.spring.studentmanagementsystemcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManagementSystemCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
