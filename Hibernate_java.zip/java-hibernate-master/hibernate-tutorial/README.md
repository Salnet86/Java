# Java Hibernate Essentials
Java Database Access with Hibernate

Author Info
-----------
Author: Andrew Gurung <br>
URL: http://www.andrewgurung.com/

-----------

## Technologies and tools used

Hibernate 5.2.6.Final
Eclipse Neon 2
Maven
MySQL 5.7.19
