<?php 



$host='localhost';
$dbname='java2016';
$username='root';
$password='';




mysql_connect('localhost', 'root', '') or die("impossibile connettersi");

mysql_select_db($dbname);



