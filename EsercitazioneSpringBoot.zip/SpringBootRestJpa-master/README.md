Progetto d'esempio dell'articolo "CRUD con Spring Boot REST JPA" 
