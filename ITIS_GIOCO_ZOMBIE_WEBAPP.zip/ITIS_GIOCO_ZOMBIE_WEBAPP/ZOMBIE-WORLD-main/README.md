# SITO (VIDEOGAME) ZOMBIE-WORLD

Videogioco su sito web realizzato come compito per le vacanze estive tra il 3° e il 4° anno.

Questo videogioco è stato realizzato utilizzando la libreria Phaser 3. Ulteriori dettagli e istruzioni del gioco sono presenti nella home page.

URL del sito: https://mattiabracco05.github.io/ZOMBIE-WORLD/
