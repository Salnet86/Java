# Creare Applicazioni Web con Spring Boot: esempi

Gli esempi completi del libro ["Creare applicazioni web con Spring Boot"](https://leanpub.com/creare-applicazioni-web-spring-boot)


## Progetti

1. [Ciao Mondo](https://github.com/davioooh/creare-applicazioni-web-spring-boot-esempi/tree/master/ciao-mondo): primi passi con Spring Boot e Spring MVC.

2. [Super Rubrica Telefonica](https://github.com/davioooh/creare-applicazioni-web-spring-boot-esempi/tree/master/super-rubrica-telefonica): una semplice applicazione web basata su Spring Boot e Thymeleaf.