# METEO

### Create OpenWeatherMap 
![image](https://user-images.githubusercontent.com/82539023/169137214-7281c35f-b156-4362-82c4-6ccc7db6364e.png)


### Screenshots

<img src="https://user-images.githubusercontent.com/82539023/169147630-77cb48a1-25cd-4e36-816f-2a5fe3fec506.jpeg" width="300" > <img src="https://user-images.githubusercontent.com/82539023/169147636-6333dbf2-48e6-42c6-aed1-abc6593bf70b.jpeg" width="300" > <img src="https://user-images.githubusercontent.com/82539023/169147648-bae1490a-d57d-441b-aaad-03952cfad7d0.jpeg" width="300" > <img src="https://user-images.githubusercontent.com/82539023/169147655-dcc76eb0-37da-40ea-8839-c8b9b1739c13.jpeg" width="300" >  <img src="https://user-images.githubusercontent.com/82539023/169147665-bda843ff-f35b-4986-ab0a-21dea11e96c9.jpeg" width="300" > <img src="https://user-images.githubusercontent.com/82539023/169148802-493d0cce-4811-4a09-a007-a580e3b84118.jpeg" width="300" >   




https://user-images.githubusercontent.com/82539023/169149504-073758cd-1b06-4e40-b2f2-b30e3c6ab8e1.mp4










