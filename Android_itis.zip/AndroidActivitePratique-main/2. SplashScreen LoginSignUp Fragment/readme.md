## 3. Splash Screen - Login - SignUp 
il est demandé de réaliser une application qui permet de
récupérer les données d’un utilisateur (Nom et mot de passe) à partir de la
première Activité et les envoyer à la deuxième activité pour les afficher. Le
démarrage de l’application se fait en premier lieu avec un écran de d’accueil qui
s’appelle un Splash Screen.


####  Screenshots
https://user-images.githubusercontent.com/82539023/161381839-d168dccf-abea-444e-9816-d9d060bb33e2.mp4

https://user-images.githubusercontent.com/82539023/161381856-2131b556-0f1e-4774-bac3-3f5e2dd05a13.mp4



