
## 7. Exercice Room Database SQLite 
 le code source d'une application qui permet d'enregistrer et afficher les données depuis une bdd SQLite en utilisant l'implémentation du RoomDataBase
 Voici les captures d'écran

####  Screenshots
<img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/7.%20SQLite%20Room/WhatsApp%20Image%202022-04-09%20at%204.24.33%20PM%20(1).jpeg" width="300" >  <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/7.%20SQLite%20Room/WhatsApp%20Image%202022-04-09%20at%204.24.33%20PM%20(2).jpeg" width="300" >  <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/7.%20SQLite%20Room/WhatsApp%20Image%202022-04-09%20at%204.24.33%20PM.jpeg" width="300" >  <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/7.%20SQLite%20Room/WhatsApp%20Image%202022-04-09%20at%204.24.34%20PM.jpeg" width="300" >

