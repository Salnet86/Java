## 5. Read and write from internal file 
 le code source d'une application qui permet de 

####  Screenshots
<img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/5.%20ReadFileWrite/Red.JPG" width="300" >


