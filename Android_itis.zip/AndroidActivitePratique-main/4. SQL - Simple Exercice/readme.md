
## 5. Read and write from internal file 
 le code source d'une application qui permet de charger les données depuis des fichiers; D'enregistrer les données dans des fichiers...

####  Screenshots
<img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/5.%20ReadFileWrite/Red.JPG" width="300" >

## 6. SQLite simple exercice  Using SQLiteOpenHelper
 le code source d'une application qui permet d'enregistrer les données dans une bdd SQLite en utilisant SQLiteOpenHelper

####  Screenshots
<img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/6.%20SQLite/WhatsApp%20Image%202022-04-09%20at%204.48.36%20PM.jpeg" > 
<img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/6.%20SQLite/WhatsApp%20Image%202022-04-09%20at%204.49.50%20PM.jpeg"  >

https://user-images.githubusercontent.com/82539023/162597261-9912e09e-5373-44f9-8af7-fb161f0a898b.mp4

## 7. Exercice Room Database SQLite 
 le code source d'une application qui permet d'enregistrer et afficher les données depuis une bdd SQLite en utilisant l'implémentation du RoomDataBase
 Voici les captures d'écran

####  Screenshots
<img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/7.%20SQLite%20Room/WhatsApp%20Image%202022-04-09%20at%204.24.33%20PM%20(1).jpeg" width="300" >  <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/7.%20SQLite%20Room/WhatsApp%20Image%202022-04-09%20at%204.24.33%20PM%20(2).jpeg" width="300" >  <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/7.%20SQLite%20Room/WhatsApp%20Image%202022-04-09%20at%204.24.33%20PM.jpeg" width="300" >  <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/7.%20SQLite%20Room/WhatsApp%20Image%202022-04-09%20at%204.24.34%20PM.jpeg" width="300" >
