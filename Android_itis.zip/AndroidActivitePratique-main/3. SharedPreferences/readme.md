

## 4. Shared Preferences  
 le code source d'une application qui permet de changer le théme en 
 et les paramètres sont sauvegardé par SharedPreferences.
 Cette application est faite avec l'API SharedPreferences et gestion de ces événements.

####  Screenshots

<img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/4.%20Shared%20preferences/WhatsApp%20Image%202022-04-01%20at%2010.47.32%20AM.jpeg" width="300" >      <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/4.%20Shared%20preferences/WhatsApp%20Image%202022-04-01%20at%2010.47.39%20AM.jpeg" width="300" >    <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/4.%20Shared%20preferences/WhatsApp%20Image%202022-04-01%20at%2010.47.46%20AM.jpeg" width="300" >  <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/4.%20Shared%20preferences/WhatsApp%20Image%202022-04-01%20at%2010.48.55%20AM.jpeg" width="300" >      <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/4.%20Shared%20preferences/WhatsApp%20Image%202022-04-01%20at%2010.47.58%20AM.jpeg" width="300" >    <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/4.%20Shared%20preferences/WhatsApp%20Image%202022-04-01%20at%2010.48.53%20AM.jpeg" width="300" >
   
