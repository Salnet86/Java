## 8. Contact App Load Data from Json File 
 le code source d'une application qui permet de charger les données à partir d'un fichier json et les gérer 

####  Screenshots

https://user-images.githubusercontent.com/82539023/162597252-2d06b315-5614-46e8-bdae-fdc3b6fa30a0.mp4

https://user-images.githubusercontent.com/82539023/162597267-8af242bb-eb35-40a9-88ab-5861cf1c3890.mp4


<img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/8.%20JsonContact/WhatsApp%20Image%202022-04-09%20at%202.55.10%20PM.jpeg" width="300" > <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/8.%20JsonContact/WhatsApp%20Image%202022-04-09%20at%202.55.11%20PM.jpeg" width="300" > <img src="https://github.com/hajar-zarguan/AndroidActivitePratique/blob/main/Capture%20d'%C3%A9cran/8.%20JsonContact/WhatsApp%20Image%202022-04-09%20at%202.55.49%20PM.jpeg" width="300" >
