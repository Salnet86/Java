#  <a href="https://developer.android.com" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/android/android-original-wordmark.svg" alt="android" width="40" height="40"/> </a> Tous mes projets  et travaux pratiques concernant Android Studio



1. [ Basics: ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/1.%20Basics)
   -  [ Constraint Layout ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/1.%20Basics/1.%20ConstraintLayout%20(basics))
   -  [ Calculatrice en utilisant Constraint Layout ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/1.%20Basics/2.%20Calculatrice)
    
2. [ SplashScreen - Login SignUp - Fragment](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/2.%20SplashScreen%20LoginSignUp%20Fragment)
3. [ SharedPreferences](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/3.%20SharedPreferences)
4. [ SQL - Simple Exercice ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/4.%20SQL%20-%20Simple%20Exercice)
   -  [ ReadAndWriteInternalFile ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/4.%20SQL%20-%20Simple%20Exercice/5.%20ReadAndWriteInternalFile)
   -  [ Exercice SQLite Simple ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/4.%20SQL%20-%20Simple%20Exercice/6.%20Exercice%20SQLite%20Simple)
   -  [ SQLite Room Simple exercice ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/4.%20SQL%20-%20Simple%20Exercice/7.%20SQLite%20Room%20Simple%20exercice)
    
5. [ Contact Json ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/5.%20Contact%20Json)
6. [ ContactApp - RoomDatabase ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/6.%20ContactApp%20%20-%20RoomDatabase)
7. [ BDD - MySQL](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/7.%20BDD%20-%20MySQL)
   -  [ MySql_AndroidStudio_JDBC ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/7.%20BDD%20-%20MySQL/10.%20MySql_AndroidStudio_JDBC)
   -  [ Retrofit Android ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/7.%20BDD%20-%20MySQL/11.%20Retrofit%20Android)
   -  [ Volley ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/7.%20BDD%20-%20MySQL/12.%20Volley)
   
8. [ Maps ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/8.%20Maps)
9. [ Meteo ](https://github.com/hajar-zarguan/AndroidActivitePratique/tree/main/9.%20Meteo)




