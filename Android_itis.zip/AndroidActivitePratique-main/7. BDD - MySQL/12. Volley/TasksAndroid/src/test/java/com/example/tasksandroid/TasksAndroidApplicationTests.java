package com.example.tasksandroid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TasksAndroidApplicationTests {

    @Test
    void contextLoads() {
    }

}
