## 1. Constraint Layout - Gestion des événements
il est demandé de réaliser une
application qui permet de mettre en pratique la
gestion des événements avec une interface graphique
un peu complexe. Il vous est proposé donc de réaliser
une calculatrice, avec l’interface graphique suivante
